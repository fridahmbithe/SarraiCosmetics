/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_term_relationships`; */
/* PRE_TABLE_NAME: `1673509067_wp_term_relationships`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1673509067_wp_term_relationships` ( `object_id` bigint(20) unsigned NOT NULL DEFAULT 0, `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0, `term_order` int(11) NOT NULL DEFAULT 0, PRIMARY KEY (`object_id`,`term_taxonomy_id`), KEY `term_taxonomy_id` (`term_taxonomy_id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1673509067_wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES (1,1,0),(6,2,0),(23,3,0),(24,3,0),(25,3,0),(26,3,0),(27,3,0),(28,3,0),(74,4,0),(74,19,0),(74,20,0),(75,4,0),(75,20,0),(75,21,0),(75,22,0),(75,23,0),(77,4,0),(77,19,0),(77,20,0),(87,4,0),(87,17,0),(94,4,0),(94,24,0);
